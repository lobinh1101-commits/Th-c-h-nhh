# Thực hành CSS - grid-row Property

## Mục tiêu
Tạo Grid gồm 3 cột, 3 hàng và dùng `grid-row` để cho Ô 1 chiếm 2 hàng liên tiếp.

## Chạy bài
1. Mở `index.html` bằng trình duyệt.
2. Mở `style.css` và sửa thuộc tính `grid-row` trong `.item1`.
3. Lưu file rồi tải lại trang để quan sát kết quả.

## Ba trường hợp cần thử
- `grid-row: 1 / 3;` — Ô 1 chiếm từ đường kẻ hàng 1 đến đường kẻ hàng 3, tức 2 hàng.
- `grid-row: 2 / 4;` — Ô 1 chiếm hàng 2 và hàng 3.
- `grid-row: span 2;` — Ô 1 chiếm 2 hàng, vị trí bắt đầu do thuật toán tự động sắp xếp Grid xác định.

## Đẩy lên GitHub
Mở terminal trong thư mục dự án và chạy:

```bash
git add index.html style.css README.md
git commit -m "Add CSS grid-row practice"
git push
```

Nếu đây là thư mục chưa được kết nối với repository, hãy chạy `git init`, thêm remote repository bằng `git remote add origin URL_REPOSITORY`, rồi thiết lập nhánh và push theo cấu hình repository của bạn.
